<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37892302-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<div class="footer">
	<hr>
	<ul>      
		<li> <a href="">About</a> </li>
		<li> <a href="">Terms</a> </li>
		<li> <a href="">Privacy</a> </li>
		<li> <a href="">Help</a> </li>
		<div class="clear"></div>
		<li class="float-none"> &copy; <?php echo date("Y");?> <a href="http://www.gossout.com">Gossout</a></li>		
	</ul> 
	<div class="clear"></div>
</div>