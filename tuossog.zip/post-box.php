<div class="post-box">
	<form>
		<textarea required placeholder="What say ye?..."></textarea>
		<p class="group-1">	
			<select> 
				<option>Ahmadu Bello University, Zaria, Nigeria </option>
				<option>Eko Radio Party</option>
				<option>Abuja, Federal Capital Territory, Nigeria</option>
			</select>
		</p>
		<p class="group-2">
			<button style="padding: 0 .5em;"><span class="icon-camera"></span></button>
			<input type="submit" class="submit button" value="Share">
		</p>
	</form>
	<div class="clear"></div>
</div>