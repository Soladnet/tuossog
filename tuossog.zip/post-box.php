<div class="post-box">
	<form>
		<textarea required placeholder="Post to a community"></textarea>
		<div class="group-1 button">	
			<select> 
				<option>Select Community to Post to...!</option>
				<option>Ahmadu Bello University, Zaria, Nigeria </option>
				<option>Eko Radio Party</option>
				<option>Abuja, Federal Capital Territory, Nigeria</option>
				<option>Abuja, Federal Capital Territory, Nigeria Abuja, Federal Capital Territory, Nigeria</option>
			</select>
		</div>
		    <input type="submit" class="submit button float-right" value="Post">
			<button class="button hint hint--left  float-right" data-hint="Upload image"><span class="icon-16-camera"></span></button>	
	</form>
	<div class="clear"></div>
</div>