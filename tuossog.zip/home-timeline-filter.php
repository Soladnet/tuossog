<div class="timeline-filter">
	<ul>
		<li><span class="icon-16-chat"></span></li>
		<li><a href="">All</a></li>
		<li><a href=""><p>Friends</p> </a></li>
		<li><a href=""><p>Community</p></a></li>
		<li class="active"><a href=""><p>Gossout</p></a></li>
	</ul>
</div>
<div class="clear"></div>