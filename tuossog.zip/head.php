<link rel="stylesheet" media="screen" href="css/style.css">
<link rel="stylesheet" href="css/hint.min.css">
<link rel="stylesheet" href="css/libnotify.css">
<link rel="shortcut icon" href="favicon.ico">

<!--<script src="scripts/svgeezy.js"></script>
<script>
    $(function() {
        svgeezy.init("nocheck", "png");
    });
</script>-->
<script type="text/javascript" src="scripts/script.js"></script>
<script type="text/javascript" src="scripts/humane.min.js"></script>
<!-- <link href='http://fonts.googleapis.com/css?family=Ubuntu|Open+Sans:300' rel='stylesheet' type='text/css'> -->
<title>Gossout - </title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" > 
<!--<script>
humane.log("Hello", {timeout: 10000, clickToClose:'true'});
</script>-->
