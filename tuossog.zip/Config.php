<?php
define("HOSTNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");
define("DATABASE_NAME", "gossout");
define("FACEBOOK_API_ID","265070990279313");
define("FACEBOOK_SECRETE","199820e1b4d517ce88c9fd4d8854032b");
?>