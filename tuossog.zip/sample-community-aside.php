<div class="aside">
				<div class="aside-wrapper">
					<img class="profile-pic" src="images/1.jpg">
					<table>
						<tr><td colspan="2"><h3>Eko Radio Party</h3></td></tr>
						<tr><td><span class="icon-16-warning"></span> Private</td></tr>
						<tr><td class="profile-meta"> ERP, a radio programme like no other... with sole objective of making serious issues light. We educate and entertain.</td></tr>
						</table>					
					<div class="clear"></div>
					<div class="profile-summary">
						<div class="profile-summary-wrapper"><a href=""><p class="number">50 </p> <p class="type">Posts</p></a></div>
						<div class="profile-summary-wrapper"><a href="communities.php"><p class="number">30 </p> <p class="type">Members</p></a></div>
						<div class="profile-summary-wrapper"><a href="all-friends.php"><p class="number">1 </p> <p class="type">Admin</p></a></div>
						<div class="clear"></div>
					</div>
					<div class="clear"></div>
		
					<button class=" button profile-button"><span class="icon-16-chat"></span> Chat</button>
					<button class=" button profile-button" id="more" onclick="javascript:toggle('pop-up-more','more');">More<span class="icon-16-checkmark"></span>
						<div class="more-container" id="pop-up-more">
							<div class="more">
								<ul>
									<li><a href=""><span class="icon-16-chat"></span> Chat</a></li>
									<li><a href=""><span class="icon-16-mail"></span> Invite Members</a></li>
									<li><a href=""><span class="icon-16-checkmark"></span> Favourite</a></li>
									<hr>
									<li><a href=""><span class="icon-16-checkmark"></span> Mute</a></li>
									<li><a href=""><span class="icon-16-cross"></span> Leave</a></li>
								</ul>
							</div>
						</div>

					</button>

					<div class="clear"></div>
			</div>
		
			
				<div class="aside-wrapper">
					<h3>Members</h3>
					<img class= "friends-thumbnails" src="images/1.jpg">
					<img class= "friends-thumbnails" src="images/2.jpg">
					<img class= "friends-thumbnails" src="images/3.jpg">
					<img class= "friends-thumbnails" src="images/snip.jpg">
					<img class= "friends-thumbnails" src="images/1.jpg">
					<p class="community-listing">
						<span>
							<span><span class="icon-16-dot"></span><a href="all-friends.php">Show all</a></span>
							<span><span class="icon-16-dot"></span><a id="show-suggested-friends" href="javascript:toggle('suggested-friends', 'show-suggested-friends');" >Suggested Friends</a></span>
						</span>
					</p>
				</div>
				<?php
				include("suggested-friends.php");
				?>
				<div class="aside-wrapper">
					<h3>Trends</h3>
					<p><a>#newGossout</a></p>
					<p><a>#newGossout</a></p>
					<p><a>#newGossout</a></p>
					<p><a>#newGossout</a></p>
					<p><a>#newGossout</a></p>
					<p class="community-listing">
						<span>
							<span><span class="icon-16-dot"></span><a href="">Show all</a></span>
						</span>
					</p>
			</div>
			
				<div class="clear"></div>
			</div>	