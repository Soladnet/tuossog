<div class="nav">
    <ul>
            <!-- <img src="images/gossout-logo-image-svg.svg" alt="gossout-logo"> -->
        <li><a href="home.php"><span class="icon-house"></span><span>Home</span></a></li>
        <li class="last"><a href="communities.php"><span class="icon-contract"></span><span>Communities</span></a></li>		
        <li class="nav-login last"><a href=""><span>Login</span><span class="icon-login"></span></a></li>
        <!-- <li><a href=""><span class="icon-search"></span></a></li> -->
        <li class="nav-search-container float-right">
            <label for="nav-search"></label>
            <input name="nav-search " placeholder="" type="text" value=""  required/>
        </li>
        <div class="clear"></div>
    </ul>
    <div class="clear"></div>
</div>				