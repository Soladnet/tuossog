<div id= "suggested-friends" class="no-display suggested-friends aside-wrapper" > 
					<h3>Suggested Friends </h3>
					<div class="all-friends-list suggested-friends">
						<div class="individual-friend-box">
							<a class= "fancybox" id="inline" href="#data1">
								<div class="friend-image">
									<img src="images/1.jpg">
								</div>
								<div class="friend-text">
									<div class="friend-name">Chiroma Chukwuma Adekunle</div>
									<div class="friend-location">Abuja, Federal Capital Territory, Nigeria</div>
								</div>
								<div style="display:none">
									<div id="data1">
										<div class="aside-wrapper">
											<img class="profile-pic" src="images/1.jpg">
											<table>
												<tr><td></td><td><h3>Ciroma Chukwuma Adekunle</h3></td></tr>
												<tr><td><span class="icon-16-map"></span></td><td class="profile-meta"> Abuja, Federal Capital Territory, Nigeria</td></tr>
												<tr><td><span class="icon-16-female"></span></td><td class="profile-meta"> Female</td></tr>
												<tr><td><span class="icon-16-male"></span></td><td class="profile-meta"> Male</td></tr>
												<tr><td><span class="icon-16-dot"></span></td><td class="profile-meta"><a href="">See Profile</a> </td></tr>
											</table>					
											<div class="clear"></div>

											<button class="profile-meta-functions button"><span class="icon-16-eye"></span> Wink</button>
											<button class="profile-meta-functions button"><span class="icon-16-mail"></span> Send Message</button>
											<button class="profile-meta-functions button"><span class="icon-16-checkmark"></span> Accept Friendship</button>

											<div class="clear"></div>
										</div>
									</div>
								</div>
							</a>
						</div>
						<div class="individual-friend-box">
							<a class= "fancybox" id="inline" href="#data2">
								<div class="friend-image">
									<img src="images/1.jpg">
								</div>
								<div class="friend-text">
									<div class="friend-name">Chiroma Chukwuma</div>
									<div class="friend-location">...</div>
								</div>
								<div style="display:none">
									<div id="data2">
										<div class="aside-wrapper">
											<img class="profile-pic" src="images/1.jpg">
											<table>
												<tr><td></td><td><h3>Ciroma Chukwuma</h3></td></tr>
												<tr><td><span class="icon-16-map"></span></td><td class="profile-meta"> Abuja, Federal Capital Territory, Nigeria</td></tr>
												<tr><td><span class="icon-16-female"></span></td><td class="profile-meta"> Female</td></tr>
												<tr><td><span class="icon-16-male"></span></td><td class="profile-meta"> Male</td></tr>
												<tr><td><span class="icon-16-dot"></span></td><td class="profile-meta"><a href="">See Profile</a> </td></tr>
											</table>					
											<div class="clear"></div>

											<button class="profile-meta-functions button"><span class="icon-16-eye"></span> Wink</button>
											<button class="profile-meta-functions button"><span class="icon-16-mail"></span> Send Message</button>
											<button class="profile-meta-functions button"><span class="icon-16-checkmark"></span> Accept Friendship</button>

											<div class="clear"></div>
										</div>
									</div>
								</div>
							</a>
						</div>
					</div>
					<div class="clear"></div>
				</div>